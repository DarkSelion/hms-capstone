<?php

namespace App\Http\Controllers\Api\Public;

use App\Http\Controllers\Controller;
use App\Mail\OtpMail;
use App\Models\ActivityLog;
use App\Models\Guest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $data = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => ['required', 'email', 'unique:guests,email', 'regex:/^[a-zA-Z0-9._%+-]+@(gmail|yahoo|outlook|hotmail|icloud|aol|protonmail|zoho|mail|live|msn|ymail|rocketmail)\.(com|ph)$/'],
            'phone' => ['required', 'string', 'max:20', 'regex:/^(\+63|0)\d{9,13}$/'],
            'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/|confirmed',
            'gender' => 'nullable|string|max:20',
        ]);

        $guest = Guest::create([
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'password' => Hash::make($data['password']),
            'gender' => $data['gender'] ?? null,
        ]);

        $token = $guest->createToken('portal-token')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $guest,
        ], 201);
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $guest = Guest::where('email', $data['email'])->first();

        if (! $guest || ! Hash::check($data['password'], $guest->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        if ($guest->is_blacklisted) {
            return response()->json(['message' => 'Account has been deactivated. Please contact support.'], 403);
        }

        $token = $guest->createToken('portal-token')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $guest,
        ]);
    }

    public function me(Request $request)
    {
        return response()->json($request->user());
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();

        return response()->json(['message' => 'Logged out successfully.']);
    }

    public function updateProfile(Request $request)
    {
        $guest = $request->user();

        $data = $request->validate([
            'first_name' => 'sometimes|string|max:255',
            'last_name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|unique:guests,email,'.$guest->id,
            'phone' => 'nullable|string|max:20|regex:/^[+]?[0-9]{10,15}$/',
            'address' => 'nullable|string',
            'city' => 'nullable|string|max:100',
            'country' => 'nullable|string|max:100',
            'nationality' => 'nullable|string|max:100',
            'date_of_birth' => 'nullable|date',
            'gender' => 'nullable|string|max:20',
            'postal_code' => 'nullable|string|max:20',
        ]);

        foreach (['date_of_birth', 'gender', 'postal_code', 'address', 'city', 'country', 'nationality'] as $field) {
            if (($data[$field] ?? null) === '') {
                $data[$field] = null;
            }
        }

        $guest->update($data);

        return response()->json($guest);
    }

    public function updatePassword(Request $request)
    {
        $data = $request->validate([
            'current_password' => 'required|string',
            'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/|confirmed',
        ]);

        $guest = $request->user();

        if (! Hash::check($data['current_password'], $guest->password)) {
            throw ValidationException::withMessages([
                'current_password' => ['The current password is incorrect.'],
            ]);
        }

        $guest->update(['password' => Hash::make($data['password'])]);

        ActivityLog::create([
            'user_id' => null,
            'action' => 'updated',
            'module' => 'auth',
            'model_type' => 'Guest',
            'model_id' => $guest->id,
            'description' => "Guest " . \App\Helpers\DataMasker::maskName($guest->full_name) . " changed password",
        ]);

        return response()->json(['message' => 'Password updated successfully.']);
    }

    public function destroyAccount(Request $request)
    {
        $guest = $request->user();

        if ($guest->reservations()->exists()) {
            return response()->json(['message' => 'Cannot delete account with reservation history. Please contact support.'], 422);
        }

        $guest->tokens()->delete();
        $guest->delete();

        return response()->json(['message' => 'Account deleted successfully.']);
    }

    public function forgotPassword(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email',
        ]);

        $guest = Guest::where('email', $data['email'])->first();

        if ($guest) {
            DB::table('otp_codes')->where('email', $guest->email)->delete();

            $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            $hashedCode = hash('sha256', $code);

            DB::table('otp_codes')->insert([
                'email' => $guest->email,
                'code' => $hashedCode,
                'expires_at' => now()->addMinutes(15),
                'used' => false,
                'created_at' => now(),
            ]);

            try {
                Mail::to($guest->email)->send(new OtpMail($code));
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('OTP email failed', [
                    'email' => $guest->email,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return response()->json([
            'message' => 'If an account exists with this email, you will receive a reset code shortly.',
        ]);
    }

    public function resetPassword(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email',
            'code' => 'required|string|size:6',
            'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/|confirmed',
        ]);

        // Per-email OTP attempt limiting (max 5 per 15 minutes)
        $attemptKey = "otp_reset_attempts:{$data['email']}";
        $attempts = (int) Cache::get($attemptKey, 0);
        if ($attempts >= 5) {
            throw ValidationException::withMessages([
                'code' => ['Too many failed attempts. Please request a new code.'],
            ]);
        }

        $otp = DB::table('otp_codes')
            ->where('email', $data['email'])
            ->where('used', false)
            ->where('expires_at', '>', now())
            ->first();

        if (! $otp || ! hash_equals($otp->code, hash('sha256', $data['code']))) {
            // Track failed attempts
            Cache::put($attemptKey, $attempts + 1, now()->addMinutes(15));

            throw ValidationException::withMessages([
                'code' => ['The code is invalid or has expired.'],
            ]);
        }

        $guest = Guest::where('email', $data['email'])->first();

        if (! $guest) {
            throw ValidationException::withMessages([
                'email' => ['No account found with this email.'],
            ]);
        }

        $guest->update(['password' => Hash::make($data['password'])]);

        DB::table('otp_codes')->where('id', $otp->id)->update(['used' => true]);
        Cache::forget("otp_reset_attempts:{$data['email']}");

        $guest->tokens()->delete();

        ActivityLog::create([
            'user_id' => null,
            'action' => 'updated',
            'module' => 'auth',
            'model_type' => 'Guest',
            'model_id' => $guest->id,
            'description' => "Guest " . \App\Helpers\DataMasker::maskName($guest->full_name) . " reset password via OTP",
        ]);

        return response()->json(['message' => 'Password reset successful. Please log in.']);
    }
}
